import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import type { Project } from "@prisma/client"

const statusLabel: Record<string, string> = {
  ACTIVE: "吏꾪뻾以?",
  ARCHIVED: "蹂닿???",
}
const statusVariant: Record<string, "default" | "secondary"> = {
  ACTIVE: "default",
  ARCHIVED: "secondary",
}

export function ProjectTable({ projects }: { projects: Project[] }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>?쒕ぉ</TableHead>
          <TableHead>?곹깭</TableHead>
          <TableHead>?닿린 ?섏젙</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {projects.length === 0 ? (
          <TableRow>
            <TableCell colSpan={3} className="text-center text-muted-foreground">
              ?꾨줈?앺듃媛 ?놁뒿?덈떎.
            </TableCell>
          </TableRow>
        ) : (
          projects.map((project) => (
            <TableRow key={project.id}>
              <TableCell className="font-medium">{project.title}</TableCell>
              <TableCell>
                <Badge variant={statusVariant[project.status]}>
                  {statusLabel[project.status]}
                </Badge>
              </TableCell>
              <TableCell>
                {new Date(project.updatedAt).toLocaleDateString("ko-KR")}
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  )
}
