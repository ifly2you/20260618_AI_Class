import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "업무 관리",
  description: "사내 업무 관리 툴",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  )
}
