"use server"

import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import { resolveProjectPagination } from "@/lib/projects/pagination"
import { createProjectSchema } from "@/lib/validations/project"
import type { Project } from "@prisma/client"

type ActionResult<T> = { data: T; error?: never } | { data?: never; error: string }

export async function listProjects(): Promise<ActionResult<Project[]>> {
  const session = await auth()
  if (!session?.user) return { error: "濡쒓렇?몄씠 ?꾩슂?⑸땲??" }

  try {
    const projects = await db.project.findMany({
      orderBy: [{ updatedAt: "desc" }, { title: "asc" }],
    })
    return { data: projects }
  } catch {
    return { error: "?꾨줈?앺듃 紐⑸줉??遺덈윭?ㅼ? 紐삵뻽?듬땲??" }
  }
}

export type ProjectListPage = {
  projects: Project[]
  page: number
  pageSize: number
  totalCount: number
  totalPages: number
  hasPrevious: boolean
  hasNext: boolean
}

export async function listProjectsPage(
  requestedPage = 1,
  pageSize = 20,
): Promise<ActionResult<ProjectListPage>> {
  const session = await auth()
  if (!session?.user) return { error: "濡쒓렇?몄씠 ?꾩슂?⑸땲??" }

  try {
    const totalCount = await db.project.count()
    const pagination = resolveProjectPagination(
      { page: String(requestedPage) },
      totalCount,
      pageSize,
    )

    const projects = await db.project.findMany({
      orderBy: [{ updatedAt: "desc" }, { title: "asc" }],
      skip: pagination.offset,
      take: pagination.take,
    })

    return {
      data: {
        projects,
        page: pagination.page,
        pageSize: pagination.pageSize,
        totalCount: pagination.totalCount,
        totalPages: pagination.totalPages,
        hasPrevious: pagination.hasPrevious,
        hasNext: pagination.hasNext,
      },
    }
  } catch {
    return { error: "?꾨줈?앺듃 紐⑸줉??遺덈윭?ㅼ? 紐삵뻽?듬땲??" }
  }
}

export async function createProject(
  formData: FormData,
): Promise<ActionResult<Project>> {
  const session = await auth()
  if (!session?.user) return { error: "濡쒓렇?몄씠 ?꾩슂?⑸땲??" }

  const parsed = createProjectSchema.safeParse({
    title: formData.get("title"),
    description: formData.get("description") || undefined,
  })
  if (!parsed.success) {
    return { error: parsed.error.issues[0].message }
  }

  try {
    const project = await db.project.create({
      data: { ...parsed.data, ownerId: session.user.id },
    })
    return { data: project }
  } catch {
    return { error: "?꾨줈?앺듃瑜??앹꽦?섏? 紐삵뻽?듬땲??" }
  }
}
