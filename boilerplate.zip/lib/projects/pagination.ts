export type ProjectPagination = {
  page: number
  pageSize: number
  totalCount: number
  totalPages: number
  offset: number
  take: number
  hasPrevious: boolean
  hasNext: boolean
}

function normalizeRequestedPage(page: string | string[] | undefined) {
  const value = Array.isArray(page) ? page[0] : page
  const parsed = Number.parseInt(value ?? "1", 10)

  if (!Number.isFinite(parsed) || parsed < 1) {
    return 1
  }

  return Math.floor(parsed)
}

export function resolveProjectPagination(
  searchParams: { page?: string | string[] | undefined },
  totalCount: number,
  pageSize = 20,
): ProjectPagination {
  const normalizedPageSize = Math.max(1, Math.floor(pageSize))
  const totalPages = Math.max(1, Math.ceil(totalCount / normalizedPageSize))
  const requestedPage = normalizeRequestedPage(searchParams.page)
  const page = Math.min(requestedPage, totalPages)
  const offset = totalCount === 0 ? 0 : (page - 1) * normalizedPageSize

  return {
    page,
    pageSize: normalizedPageSize,
    totalCount,
    totalPages,
    offset,
    take: normalizedPageSize,
    hasPrevious: page > 1,
    hasNext: page < totalPages,
  }
}
