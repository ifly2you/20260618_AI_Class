import { describe, expect, it } from "vitest"
import { resolveProjectPagination } from "./pagination"

describe("resolveProjectPagination", () => {
  it("defaults to the first page when no page is provided", () => {
    expect(resolveProjectPagination({}, 0)).toEqual({
      page: 1,
      pageSize: 20,
      totalCount: 0,
      totalPages: 1,
      offset: 0,
      take: 20,
      hasPrevious: false,
      hasNext: false,
    })
  })

  it("clamps invalid page values to the first page", () => {
    expect(resolveProjectPagination({ page: "abc" }, 41, 20)).toMatchObject({
      page: 1,
      totalPages: 3,
      offset: 0,
      hasPrevious: false,
      hasNext: true,
    })
  })

  it("caps the requested page at the last available page", () => {
    expect(resolveProjectPagination({ page: "99" }, 41, 20)).toMatchObject({
      page: 3,
      totalPages: 3,
      offset: 40,
      hasPrevious: true,
      hasNext: false,
    })
  })
})
